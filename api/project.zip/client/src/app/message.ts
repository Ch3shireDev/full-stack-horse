export class Message {
  public id: number;
  public content: string;
}
