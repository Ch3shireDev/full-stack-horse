﻿namespace api.Models
{
    public class Message
    {
        public int Id { get; set; }
        public string Content { get; set; }
    }
}