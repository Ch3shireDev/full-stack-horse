using Microsoft.AspNetCore.Identity;

namespace api
{
    public class ApplicationUser : IdentityUser
    {
    }
}