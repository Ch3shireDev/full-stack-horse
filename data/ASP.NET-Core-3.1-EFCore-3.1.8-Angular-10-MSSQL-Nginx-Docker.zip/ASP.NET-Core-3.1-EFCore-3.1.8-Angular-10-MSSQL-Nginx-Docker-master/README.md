# ASP.NET-Core-3.1-EFCore-3.1.8-Angular-10-MSSQL-Nginx-Docker

Example project using ASP.NET Core, Entity Framework Core, Angular 10, MSSQL database and Nginx server.

Built for http://fulstackhorse.com (https://ch3shiredev.github.io/full-stack-horse)